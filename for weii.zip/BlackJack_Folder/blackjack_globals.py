import multiprocessing as mp

class Message():

    def __init__(self, id, content):
        self.id = id
        self.content = content